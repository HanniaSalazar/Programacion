﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace L9_HFSM1123021
{
    internal class Program
    {

        static void Main(string[] args)
        {
            int modelo = 0;
            double precio = 0;
            string marca = "";
            bool disponible = false;
            string d = " ";
            double tipoCambioDolar = 7.80;
            double descuentoAplicado = 0;


            //Solicito un descuento, mostrar info del carro y mostrar los datos con el descuento
            //mostrar el descuento y precio en dolares y en quetzales. PROCEDIMIENTO PARA CALCULAR.

            Console.WriteLine("Ingrese el modelo del automóvil: ");
            modelo = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el precio del automóvil: ");
            precio = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la marca del automóvil: ");
            marca = Console.ReadLine();

            Console.WriteLine("¿El modelo está disponible?" + "(SI/NO)");
            d = Console.ReadLine();

            if (d == "SI")
            {
                disponible = true;

            }
            else if (d == "NO")
            {
                disponible = false;
            }

            Console.WriteLine("Ingrese el descuento por aplicar: "+ "(En Q)");
            descuentoAplicado = double.Parse(Console.ReadLine());

            Console.WriteLine("");
            resultado(precio,tipoCambioDolar, disponible, modelo, marca,descuentoAplicado);
        }

        public static void resultado(double precio, double cambio, bool disponible, int modelo,string marca, double descuento)
        {
            double precioD = precio/ cambio;

            descuento = precio-descuento;

            double descuentoD= descuento/ cambio;
            

            Console.WriteLine("Modelo: " + modelo.ToString("#,###"));
            Console.WriteLine("Marca: " + marca);
            Console.WriteLine("Disponibilidad:");
            if (disponible == true)
            {
                Console.WriteLine("SI está disponible");
            }
            else if (disponible==false)
            {
                Console.WriteLine("NO está disponible");
            }
            Console.WriteLine("El precio en dólares es: "+ precioD.ToString("###,###,###,###.##"));
            Console.WriteLine("El precio en quetzales es: "+ precio.ToString("###,###,###,###.##"));
            Console.WriteLine("El descuento en dólares es de: " + descuentoD.ToString("###,###,###,###.##"));
            Console.WriteLine("El descuento en quetzales es de: " + descuento.ToString("###,###,###,###.##"));
            Console.ReadKey();

        }
    }
}