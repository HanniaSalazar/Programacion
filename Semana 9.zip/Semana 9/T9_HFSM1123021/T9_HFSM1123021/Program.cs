﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9_HFSM1123021
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int modelo = 0;
            double precio = 0;
            string marca = "";
            bool disponible = false;
            string d = " ";
            double tipoCambioDolar = 7.80;
            double IVA = 0.12; //Defecto dado por el constructor en el lab 9

            Console.WriteLine("Ingrese el modelo de la motocicleta: ");
            modelo = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el precio de la motocicleta: ");
            precio = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la marca de la motocicleta: ");
            marca = Console.ReadLine();

            Console.WriteLine("¿El modelo está disponible?" + "(SI/NO)");
            d = Console.ReadLine();

            if (d == "SI")
            {
                disponible = true;

            }
            else if (d == "NO")
            {
                disponible = false;
            }

            Console.WriteLine("");
            resultado(precio, tipoCambioDolar, disponible, modelo, marca, IVA);
        }

        public static void resultado(double precio, double cambio, bool disponible, int modelo, string marca, double IVA)
        {
            double precioD = precio / cambio;

            IVA = precio+(precio * IVA);

            double IVAtotal = IVA-precio;


            Console.WriteLine("Modelo: " + modelo.ToString("#,###"));
            Console.WriteLine("Marca: " + marca);
            Console.WriteLine("Disponibilidad:");
            if (disponible == true)
            {
                Console.WriteLine("SI está disponible");
            }
            else if (disponible == false)
            {
                Console.WriteLine("NO está disponible");
            }
            Console.WriteLine("El precio sin IVA en dólares es: " + precioD.ToString("###,###,###,###.##"));
            Console.WriteLine("El precio sin IVA en quetzales es: " + precio.ToString("###,###,###,###.##"));
            Console.WriteLine("El precio con IVA en quetzales es " + IVA.ToString("###,###,###,###.##"));
            Console.WriteLine("El monto del IVA en quetzales es: " + IVAtotal.ToString("###,###,###,###.##"));
            Console.ReadKey();

        }
    }
}
        