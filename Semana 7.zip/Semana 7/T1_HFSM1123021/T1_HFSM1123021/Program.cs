﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1_HFSM1123021
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");
            Console.ReadLine();
            Console.Clear();
            string sNombre;
            string sEdad;
            string sCarrera;
            string sCarné;
            Console.ReadKey();
            Console.Clear();
            

            Console.WriteLine("Mi segundo programa");
            Console.ReadLine();
            Console.WriteLine("Nombre:");
            //Entrada
            sNombre = Console.ReadLine();
            // SALIDA
            Console.WriteLine("Edad:");
            //Entrada
            sEdad = Console.ReadLine();
            // SALIDA
            Console.WriteLine("Carrera:");
            //Entrada
            sCarrera = Console.ReadLine();
            // SALIDA
            Console.WriteLine("Carné:");
            //Entrada
            sCarné = Console.ReadLine();
            //Salida
            Console.ReadKey();

            Console.WriteLine("Nombre:" + sNombre);
            Console.ReadLine();
            Console.WriteLine("Edad:" + sEdad);
            Console.ReadLine();
            Console.WriteLine("Carrera:" + sCarrera);
            Console.ReadLine();
            Console.WriteLine("Carné:" + sCarné);
            Console.ReadLine();

            Console.Write("Soy " + sNombre + " tengo " + sEdad + " años y estudio la carrera de " + sCarrera + " mi número de carné es: " + sCarné);
            Console.ReadKey();
        }
    }
}
