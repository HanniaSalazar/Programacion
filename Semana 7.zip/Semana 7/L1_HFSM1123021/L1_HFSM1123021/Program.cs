﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1_HFSM1123021
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su nombre: ");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy HANNIA");

            /* Al poner WriteLine escribe las frases en una linea diferente en cambio en Write lo escribe en una misma linea*/

            Console.Write("Hola Mundo");
            Console.Write(" soy HANNIA");
            Console.ReadKey();
        }
    }
}
