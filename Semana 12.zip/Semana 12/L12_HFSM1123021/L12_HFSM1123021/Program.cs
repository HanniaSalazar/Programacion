﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_HFSM1123021
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] tabla1 = new int[4, 5];
            int[,] tabla2 = new int[4, 5]; 
            int[,] tabla3 = new int[4, 5]; ;

            Random r = new Random();

            int i = 0;
            int j = 0;
            double sumatoria1 = 0;
            double sumatoria2 = 0;

            Console.WriteLine("Actividad No.1");
            Console.WriteLine("Tabla No.1");
            Console.WriteLine("");
            for (i = 0; i < 4; i++)
            {
                for(j = 0; j < 5; j++)
                {
                    tabla1[i, j] = r.Next(0,100);
                }
            }

            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    Console.Write(" " + tabla1[i, j]);

                }
                Console.WriteLine();
            }

            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    sumatoria1 = sumatoria1+ tabla1[i,j];
                }
            }
            Console.WriteLine("La sumatoria de la tabla no.1 es: " + sumatoria1);

            double promedio = sumatoria1 / tabla1.Length;

            Console.WriteLine("El promedio de la tabla No.1 es: " + promedio);

            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("Actividad No.2");
            Console.WriteLine("Tabla No.2");
            Console.WriteLine("");
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    tabla2[i, j] = r.Next(0, 100);
                }
            }
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    Console.Write(" " + tabla2[i, j]);

                }
                Console.WriteLine();
            }

            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    sumatoria2 = sumatoria2 + tabla2[i, j];
                }
            }
            Console.WriteLine("La sumatoria de la tabla no.2 es: " + sumatoria2);

            double promedio1 = sumatoria1 / tabla2.Length;

            Console.WriteLine("El promedio de la tabla No.2 es: " + promedio1);
            Console.ReadKey();


            Console.Clear();
            Console.WriteLine("Actividad No.3");
            for ( i = 0; i <  4; i++)
            {
                for ( j = 0; j < 5; j++)
                {
                    tabla3[i, j] = tabla1[i, j] + tabla2[i, j];
                }
            }
            Console.WriteLine("La sumatoria de las Matrices 1 y 2 es :");
            for ( i = 0; i < 4; i++)
            {
                Console.Write("\n");
                for (j = 0; j <5; j++)
                {
                    Console.Write(tabla3[i, j] + "  ");
                }
            }
            Console.ReadKey();
            }

        }
    }

