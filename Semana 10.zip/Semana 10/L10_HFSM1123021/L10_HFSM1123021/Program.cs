﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_HFSM1123021
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int contador = 3;
            
            do
            {
                Console.WriteLine("Ingrese un nombre de usuario:");
                string usuario = Console.ReadLine();

                Console.WriteLine("Ingrese una contraseña:");
                string contra = Console.ReadLine();

                bool val = Login(usuario, contra);

                if (val == false)
                {
                    contador--;
                    Console.WriteLine("Le quedan " + contador + " intentos");
                }
                else
                {
                    Console.WriteLine("Usuario y contraseña correctos");
                    contador = 0;
                }
            }
            while (contador >0);

            Console.ReadKey();
        }

        static bool Login(string usuario, string contra){

            bool validar = false;

            if (usuario == "usuario1")
            {
                if (contra == "asdasd")
                {
                    validar = true;
                }
            }
            
            return validar;
            }
}
}
