﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace L11_HFSM1123021
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int seccion1 = 0;
                double[] S1;
                int seccion2 = 0;
                double[] S2;

                //SECCION NO.1
                Console.WriteLine("Ingrese la cantidad de alumnos de la sección 1");
                seccion1 = Convert.ToInt32(Console.ReadLine());
                S1 = new double[seccion1];

                for (int i = 0; i < S1.Length; i++)
                {
                    Console.WriteLine("Ingrese la calificación del alumno " + (i + 1) + " de la sección 1: ");
                    S1[i] = Convert.ToInt32(Console.ReadLine());
                }

                Console.WriteLine(" ");
                //SECCION NO.2
                Console.WriteLine("Ingrese la cantidad de alumnos de la sección 2");
                seccion2 = Convert.ToInt32(Console.ReadLine());
                S2 = new double[seccion2];

                for (int i = 0; i < S2.Length; i++)
                {
                    Console.WriteLine("Ingrese la calificación del alumno " + (i + 1) + " de la sección 2: ");
                    S2[i] = Convert.ToInt32(Console.ReadLine());
                }

                int aprobados = 0;
                int reprobados = 0;
                int paprobados = 0;
                int preprobados = 0;


                //El porciento de aprobados y desaprobados de cada sección
                Console.WriteLine(" ");
                Console.WriteLine("ACTIVIDAD A");
                //SECCION NO.1
                for (int i = 0; i < S1.Length; i++)

                    if (S1[i] >= 65)
                    {
                        aprobados = aprobados + 1;

                        paprobados = (100 * aprobados) / seccion1;

                    }
                    else if (S1[i] <= 65)
                    {
                        reprobados = reprobados + 1;
                        preprobados = (100 * reprobados) / seccion1;
                    }

                Console.WriteLine("El porcentaje de aprobados de la seccion No.1 es: " + paprobados);
                Console.WriteLine("El porcentaje de reprobados de la seccion No.1 es: " + preprobados);

                Console.WriteLine(" ");
                //SECCION NO.2
                int aprobados2 = 0;
                int reprobados2 = 0;
                int paprobados2 = 0;
                int preprobados2 = 0;

                for (int i = 0; i < S2.Length; i++)

                    if (S2[i] >= 65)
                    {
                        aprobados2 = aprobados2 + 1;

                        paprobados2 = (100 * aprobados2) / seccion2;


                    }
                    else if (S2[i] <= 65)
                    {
                        reprobados2 = reprobados2 + 1;
                        preprobados2 = (100 * reprobados2) / seccion2;
                    }

                Console.WriteLine("El porcentaje de aprobados de la seccion No.2 es: " + paprobados2);
                Console.WriteLine("El porcentaje de reprobados de la seccion No.2 es: " + preprobados2);

                Console.WriteLine(" ");
                //El porciento de desaprobados de cada sección
                Console.WriteLine("ACTIVIDAD B");
                Console.WriteLine(" ");
                Console.WriteLine("El porcentaje de reprobados de la seccion No.1 es: " + preprobados);
                Console.WriteLine("El porcentaje de reprobados de la seccion No.2 es: " + preprobados2);

                Console.WriteLine(" ");
                //El porciento de aprobados de las dos secciones.
                Console.WriteLine("ACTIVIDAD C");

                int aprobados1y2 = (aprobados + aprobados2);
                int secciones = seccion1 + seccion2;

                double resultadoC = (aprobados1y2 * 100) / secciones;

                Console.WriteLine("El porcentaje de aprobados de las dos secciones es: " + resultadoC);

                Console.WriteLine(" ");
                //El porciento de desaprobados de las dos secciones.
                Console.WriteLine("ACTIVIDAD D");
                int reprobados1y2 = (reprobados + reprobados2);
                int secciones1y2 = seccion1 + seccion2;

                double resultadoD = (reprobados1y2 * 100) / secciones1y2;

                Console.WriteLine("El porcentaje de reprobados de las dos secciones es: " + resultadoD);

                Console.WriteLine(" ");
                //El promedio de notas de cada sección.
                Console.WriteLine("ACTIVIDAD E");
                double promedio1 = 0;
                double suma1 = 0;
                //SECCION 1
                for (int i = 0; i < S1.Length; i++)
                {
                    suma1 += S1[i];
                    promedio1 = suma1 / S1.Length;
                }
                Console.WriteLine("El promedio de la seccion No.1 es: " + promedio1.ToString("0.##"));

                //SECCION 2
                double promedio2 = 0;
                double suma = 0;
                for (int i = 0; i < S2.Length; i++)
                {
                    suma += S2[i];
                    promedio2 = suma / S2.Length;
                }
                Console.WriteLine("El promedio de la seccion No.2 es: " + promedio2.ToString("0.##"));

                Console.WriteLine(" ");
                //El promedio de notas total.
                Console.WriteLine("ACTIVIDAD F");
                double promedio = (promedio1 + promedio2) / 2;

                Console.WriteLine("El promedio total es: " + promedio.ToString("0.##"));

                Console.WriteLine(" ");
                //La cantidad de estudiantes que tenga un promedio por encima de 90
                Console.WriteLine("ACTIVIDAD G");
                int aprobados1 = 0;
                for (int i = 0; i < S1.Length; i++)
                    if (S1[i] >= 90)
                    {
                        aprobados1 += 1;
                    }
                Console.WriteLine("La cantidad de estudiantes aprobados con un promedio por encima de 90 de la seccion 1 es: " + aprobados1);

                int aprobadosS2 = 0;
                for (int i = 0; i < S2.Length; i++)
                    if (S2[i] >= 90)
                    {
                        aprobadosS2 += 1;
                    }
                Console.WriteLine("La cantidad de estudiantes aprobados con un promedio por encima de 90 de la seccion 2 es: " + aprobadosS2);


                Console.WriteLine(" ");
                //La cantidad de estudiantes que tenga un promedio por debajo de 75
                Console.WriteLine("ACTIVIDAD H");
                int reprobados75 = 0;
                for (int i = 0; i < S1.Length; i++)
                    if (S1[i] <= 75)
                    {
                        reprobados75 += 1;
                    }
                Console.WriteLine("La cantidad de estudiantes con menos de 75 puntos de la seccion 1 es: " + reprobados75);

                int reprobadosS75 = 0;
                for (int i = 0; i < S2.Length; i++)
                    if (S2[i] <= 75)
                    {
                        reprobadosS75 += 1;
                    }
                Console.WriteLine("La cantidad de estudiantes con menos de 75 puntos de la seccion 2 es: " + reprobadosS75);

                Console.ReadKey();
            }
            catch
            {
                Console.WriteLine("Debe ingresar un número");
            }
            Console.ReadKey();
            Console.Clear();

        }
    }
}
