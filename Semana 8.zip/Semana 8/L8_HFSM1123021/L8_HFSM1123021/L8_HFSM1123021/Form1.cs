﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_HFSM1123021
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label2.Text = "";
            textBox1.Text = "0";

        }
        void calcularSumatoria()
        {
            label2.Text = "";
            int N = Convert.ToInt32(textBox1.Text);
            int sumatoria = 0;
            int contador = N; 


            while (contador !=0)
            {
                sumatoria = sumatoria + contador;
                contador--; 
            }
            label2.Text = sumatoria.ToString();
        }
        void factorial()
        {
            int factorialResult = 1;
            for (int i = Convert.ToInt32(textBox3.Text); i >0; i--)
            {
                factorialResult = factorialResult * i;
            }
            label5.Text = factorialResult.ToString();
        }
        void tablaMultiplicar()
        {
            richTextBox1.Clear();
            for (int i = 1; i <= 10; i++)
            {
                richTextBox1.AppendText(textBox4.Text + " * " + i + " = " + Convert.ToInt32(textBox4.Text)*i + "\n"); 
            }
        }
        bool perfecto()
        {
            if (Convert.ToInt32(textBox2.Text) == 1)
            {
                return false; 
            }
            int suma = 1;
            for (int i = 2; i < Convert.ToInt32(textBox2.Text); i++)
            {
                if (Convert.ToInt32(textBox2.Text) % i == 0)
                {
                    suma += i;
                }
            }
            if (suma == Convert.ToInt32(textBox2.Text))
            {
                return true; 
            }
            return false; 
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int op = comboBox1.SelectedIndex;
            tabControl.SelectTab(op);

            switch(op)
            {
                case 1:
                    tabControl.SelectTab(op);
                    
            

                    break;
                case 2:
                    tabControl.SelectTab(op);
                break;
                case 3:
                     tabControl.SelectTab(op);

              

                break;
                case 4:
                    tabControl.SelectTab(op);


                    break;
                default:
                    Console.WriteLine("Ingrese una opción válida");
                break;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            calcularSumatoria();
        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            factorial();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tablaMultiplicar();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (perfecto())
            {
                label7.Text = "Es perfecto"; 
            }
            else
            {
                label7.Text = "El número NO es perfecto";

            }
        }
    }
}
