﻿using System;

namespace Proyecto_Fase2_1269321_1123021
{
    class Program
    {
        public static bool[] iluminacionCuartos;
        
        public static double humedad = 0.7;
        public static int numCuartos;

        public static int tempMax { get; set; } = 22;
        public static int tempMin { get; set; } = 18;

        public static int[] ventilacion;

        public static int cantVentilacion = 0;

        static void Main(string[] args)
        {

            Console.WriteLine("Bienvenido, antes de empezar ingrese el número de cuartos de la casa: ");
            numCuartos = int.Parse(Console.ReadLine());
            iluminacionCuartos = new bool[numCuartos];
            menuPrincipal();
            Console.Clear();

            Console.WriteLine("Vuelva pronto");
            Console.ReadKey();            
        }

        public static void menuPrincipal()
        {
            int opcion;
            Console.Clear();
            Console.WriteLine("MENU PRINCIPAL");
            Console.WriteLine("1. VENTILACIÓN");
            Console.WriteLine("2. CALEFACCIÓN");
            Console.WriteLine("3. ILUMINACIÓN");
            Console.WriteLine("4. PANEL DE CONTROL");
            Console.WriteLine("5. Salir");
            Console.WriteLine("Ingrese la opción que desea elegir");
            //Se elige la opción del panel de control
            opcion = int.Parse(Console.ReadLine());
            switch (opcion)
            {
                case 1:
                    mostrarVentilacion();
                    break;

                case 2:
                    calefaccion();
                    break;

                case 3:
                    iluminacion();
                    break;

                case 4:
                    panelDeControl();
                    break;

                default:
                    Console.WriteLine("No eligió una opción válida");
                    break;
            }
        }

        public static void mostrarVentilacion()
        {
            Console.Clear();
            if (cantVentilacion == 0)
            {
                int seleccionar;
                Console.WriteLine("Aún no ha programado la ventilación ¿Desea ir al panel de control para programarla? Sí = 1 , No = 2");
                seleccionar = int.Parse(Console.ReadLine());
                if(seleccionar == 1)
                {
                    panelDeControl();
                }
                else
                {
                    menuPrincipal();
                }
            }
            else
            {
                Console.Write("La ventilación se encenderá a las ");
                for (int i = 0; i < cantVentilacion; i++)
                {
                    Console.Write(ventilacion[i] + ", ");
                }
            }
            
            Console.ReadKey();
            Console.ReadKey();
            menuPrincipal();
        }

        public static void calefaccion()
        {
            Console.Clear();
            double promedioTemperatura;
            promedioTemperatura = (tempMax + tempMin) / 2;

            Console.WriteLine("2. CALEFACCIÓN");
            Console.WriteLine("La temperatura máxima manejada por el sistema es: " + tempMax + " grados");
            Console.WriteLine("La temperatura mínima manejada por el sistema es: " + tempMin + " grados");
            Console.WriteLine("la temperatura promedio es: " + promedioTemperatura);
            Console.ReadKey();
            Console.ReadKey();
            menuPrincipal();
        }

        //Se valida si hay una persona en la habitión, y en caso de que sí se enciende la luz de dicho cuarto
        public static void iluminacion()
        {
            Console.Clear();
            int habitacionOcupada = 0;
            Console.WriteLine("3. ILUMINACIÓN");
            Console.WriteLine();
            

            for (int i = 0; i < numCuartos; i++)
            {
                Console.WriteLine("¿El cuarto " + (i + 1) + " está ocupado? Sí = 1, No = 2");
                habitacionOcupada = int.Parse(Console.ReadLine());
                if (habitacionOcupada == 1)
                {
                    iluminacionCuartos[i] = true;
                }
                else
                {
                    if (habitacionOcupada == 2)
                    {
                        iluminacionCuartos[i] = false;
                    }
                    else
                    {
                        Console.WriteLine("Opción no válida");
                    }
                }
            }

            for (int i = 0; i < numCuartos; i++)
            {
                if(iluminacionCuartos[i] == true)
                {
                    Console.WriteLine("El cuarto " + (i + 1) + " tiene la luz encendida");
                }
                else
                {
                    Console.WriteLine("El cuarto " + (i + 1) + " tiene la luz apagada");
                }
                
            }
            Console.WriteLine("Vuelva pronto");
            Console.ReadKey();
            Console.ReadKey();
            menuPrincipal();
            
        }

        public static void panelDeControl()
        {
            int opcionPanelCntrl;
            Console.Clear();
            Console.WriteLine("PANEL DE CONTROL");
            Console.WriteLine("1. VENTILACION");
            Console.WriteLine("2. TEMPERATURAS MÁXIMAS Y MÍNIMAS");
            Console.WriteLine("3. PROMEDIO DE TEMPERATURAS MÁXIMAS Y MÍNIMAS");
            Console.WriteLine("4. Regresar al menu principal");
            Console.WriteLine("Elija una opción: ");
            opcionPanelCntrl = int.Parse(Console.ReadLine());

            switch (opcionPanelCntrl)
            {
                case 1:
                    programarVentilacion();
                    break;

                case 2:
                    tempMaxMin();
                    break;

                case 3:
                    promedioTemperaturas();
                    break;

                case 4:
                    menuPrincipal();
                    break;
            }

        }

        public static void programarVentilacion()
        {
            Console.Clear();
            Console.WriteLine("1. VENTILACIÓN");
            Console.WriteLine("Ingrese la cantidad de veces que desea encender el sistema de ventilación en el día");
            cantVentilacion = int.Parse(Console.ReadLine());

            ventilacion = new int[cantVentilacion];

            for (int i = 0; i < cantVentilacion; i++)
            {
                Console.WriteLine("Ingrese la " + (i + 1) + " hora que desea ingresar");
                ventilacion[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Se ingresaron las horas correctamente");

            /*
            Console.Write("La ventilación se encenderá a las ");
            for (int i = 0; i < cantVentilacion; i++)
            {
                Console.Write(ventilacion[i] + ", ");
            }*/

            Console.ReadKey();
            Console.ReadKey();
            panelDeControl();
        }

        public static void tempMaxMin()
        {
            Console.Clear();
            Console.WriteLine("Ingrese la temperatura máxima manejada por el sistema de calefaccion: ");
            tempMax = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese la temperatura mínima manejada por el sistema de calefaccion: ");
            tempMin = int.Parse(Console.ReadLine());

            Console.WriteLine("La temperatura máxima se estableció en " + tempMax);
            Console.WriteLine("La temperatura mínima se estableció en " + tempMin);

            Console.ReadKey();
            Console.ReadKey();
            panelDeControl();
        }

        public static void promedioTemperaturas()
        {
            Console.Clear();
            double promedioTemp;
            promedioTemp = (tempMax + tempMin) / 2;
            Console.WriteLine("El promedio de las temperaturas máximas y mínimas es: " + promedioTemp);
            Console.ReadKey();
            Console.ReadKey();
            panelDeControl();
        }
    }
}
